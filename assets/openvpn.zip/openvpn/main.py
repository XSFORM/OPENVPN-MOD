# coding=utf-8
import ipaddress
import random

import functions.client as client
from functions.data.settings import *
from functions.list import *
from functions.other import *
from functions.server_control import *

console = Console()


def main_menu_statistics():
    total_keys = len(get_keys_db())
    total_keys_blocked = len(get_keys_by_status_db(False))
    total_keys_active = len(get_keys_by_status_db(True))
    total_keys_connected = len(get_keys_by_connected_db())
    total_keys_expired = len(get_expired_keys_db())
    total_keys_not_expired = len(get_not_expired_keys_db())
    total_configs = len(get_configs_db())
    total_traffic = math_bytes(get_total_keys_bytes_db())
    console.print(f'Всего ключей: {total_keys}')
    console.print(f'Активных ключей: {total_keys_active}')
    console.print(f'Заблокированных ключей: {total_keys_blocked}')
    console.print(f'Подключенных ключей: {total_keys_connected}')
    console.print(f'Истекших ключей: {total_keys_expired}')
    console.print(f'Не истекших ключей: {total_keys_not_expired}')
    console.print(f'Всего конфигураций: {total_configs}')
    console.print(f'Всего трафика: {total_traffic}')
    for config in get_configs_db():
        console.print(f'───────────── {config.port}:{config.protocol} ──────────────')
        console.print(f'Адрес конфигурации: {config.address}')
        console.print(f'Ключей в конфигурации: {len(get_keys_by_config_db(config.id))}')
        console.print(f'Активных ключей: {len(get_keys_by_config_and_status_db(config.id, True))}')
        console.print(f'Заблокированных ключей: {len(get_keys_by_config_and_status_db(config.id, False))}')
        console.print(f'Подключенных ключей: {len(get_keys_by_config_and_connected_db(config.id, True))}')
        console.print(f'Истекших ключей: {len(get_expired_keys_by_config_db(config.id))}')
        console.print(f'Не истекших ключей: {len(get_not_expired_keys_by_config_db(config.id))}')
        console.print(f'Трафик: {math_bytes(get_total_key_bytes_by_config_db(config.id))}')
        if config.id == 1:
            status = subprocess.getoutput(f'systemctl status openvpn@server')
        else:
            status = subprocess.getoutput(f'systemctl status openvpn@server-{config.protocol}-{config.port}')
        if 'Active: active (running)' in status:
            console.print(f'Статус: [bold green]Активен[/bold green]')
        else:
            console.print(f'Статус: [bold red]Не активен[/bold red]')


def select_keys() -> list:
    clear()
    console.print('────────── Меню просмотра ключей ──────────\n'
                  '1 ➤ Просмотр всех ключей\n'
                  '2 ➤ Просмотр по конфигурации\n'
                  '3 ➤ Просмотр ключей по порту\n'
                  '4 ➤ Просмотр ключей по протоколу\n'
                  '5 ➤ Просмотр ключей по имени\n'
                  '6 ➤ Просмотр ключей по email\n'
                  '7 ➤ Просмотр ключей по статусу\n'
                  '8 ➤ Просмотр подключенных ключей\n'
                  '9 ➤ Просмотр ключей по дате создания\n'
                  '10 ➤ Просмотр ключей по дате окончания\n'
                  '11 ➤ Просмотр ключей по дате обновления\n'
                  '12 ➤ Просмотр ключей по трафику\n'
                  '13 ➤ Просмотр ключей по количеству сессий\n'
                  '14 ➤ Просмотр ключей по общему времени подключения\n'
                  '15 ➤ Просмотр ключей по оставшемуся времени\n'
                  '16 ➤ Просмотр истекших ключей\n'
                  '17 ➤ Просмотр свободных ключей\n'
                  '───────────────────────────────────────────\n'
                  '0 ➤ Вернуться в главное меню\n'
                  '───────────────────────────────────────────')
    choice = console.input('Введите номер: ')
    if choice == '1':
        keys = view_all_keys()
    elif choice == '2':
        keys = view_keys_by_config()
    elif choice == '3':
        keys = view_keys_by_port()
    elif choice == '4':
        keys = view_keys_by_protocol()
    elif choice == '5':
        keys = view_keys_by_name()
    elif choice == '6':
        keys = view_keys_by_email()
    elif choice == '7':
        keys = view_keys_by_status()
    elif choice == '8':
        keys = view_keys_by_connected()
    elif choice == '9':
        keys = view_keys_by_created()
    elif choice == '10':
        keys = view_keys_by_expired()
    elif choice == '11':
        keys = view_keys_by_updated()
    elif choice == '12':
        keys = view_keys_by_traffic()
    elif choice == '13':
        keys = view_keys_by_sessions()
    elif choice == '14':
        keys = view_keys_by_total_time()
    elif choice == '15':
        keys = view_keys_by_expired_days()
    elif choice == '16':
        keys = view_expired_keys()
    elif choice == '17':
        keys = view_free_keys()
    elif choice == '0':
        keys = []
        main_menu()
    else:
        keys = []
        select_keys()
    return keys


def table_start(table):
    table.add_column('ID', justify='center')
    table.add_column('Имя', justify='center')
    table.add_column('Порт:Протокол', justify='center')


def create_key():
    clear()
    settings = get_settings_db()
    table = Table(header_style='bold magenta')
    table.title = 'Список конфигураций'
    table.add_column('ID', justify='center', style='dim', no_wrap=True)
    table.add_column('Порт', justify='center', style='dim', no_wrap=True)
    table.add_column('Протокол', justify='center', style='dim', no_wrap=True)
    table.add_column('Подсеть', justify='center', style='dim', no_wrap=True)
    table.add_column('Адрес', justify='center', style='dim', no_wrap=True)
    for config in get_configs_db():
        table.add_row(str(config.id), str(config.port), config.protocol, config.subnet, config.address)
    console.print(table)
    config_id = console.input('\nВведите номер конфигурации: ')
    name = console.input('Введите имя ключа[Рандомное]: ')
    email = '' if not settings.use_mail else console.input('Введите email[Пусто]: ')
    days = console.input('Введите количество дней действия ключа[30]: ')
    amount = console.input('Введите количество ключей[1]: ')
    console.print('\nСоздание ключей...\n')
    client.create_key(name=random_name() if name == '' else name,
                      email=None if email == '' else email,
                      days=30 if days == '' else int(days),
                      amount=1 if amount == '' else int(amount),
                      config_id=int(config_id))
    input('Нажмите Enter для продолжения...')
    main_menu()


def delete_key():
    clear()
    keys = select_keys()
    clear()
    table = Table(header_style='bold deep_sky_gray4')
    table.add_column('ID', justify='center')
    table.add_column('Имя', justify='center')
    table.add_column('Осталось дней', justify='center')
    table.add_column('Порт:Протокол', justify='center')
    for i in keys:
        key = get_key_by_id(int(i))
        if not key.free_key:
            config = str(key.config_id.port) + ':' + key.config_id.protocol
        else:
            config = 'Не привязан'
        table.add_row(str(key.id), key.name, str(get_key_time_for_list(str(key.expired))),
                      config)
    console.print(table)
    answer = 'n' if console.input('Подтвердите удаление[Y]: ').lower() == 'n' else 'y'
    if answer.lower() == 'y':
        clear()
        for i in keys:
            client.delete_key(int(i))
        input('Ключи успешно удалены. Нажмите Enter для продолжения...')
        main_menu()
    else:
        input('Удаление ключей отменено. Нажмите Enter для продолжения...')
        main_menu()


def edit_days_key():
    keys = select_keys()
    clear()
    table = Table(header_style='bold deep_sky_gray4')
    table.title = 'Список ключей'
    table_start(table)
    table.add_column('Осталось дней', justify='center')
    for i in keys:
        key = get_key_by_id(int(i))
        if not key.free_key:
            config = str(key.config_id.port) + ':' + key.config_id.protocol
        else:
            config = 'Не привязан'
        table.add_row(str(key.id), key.name, config, str(get_key_time_for_list(str(key.expired))))
    console.print(table)
    days_ = console.input('Введите срок ключа\n'
                          '30 (фиксированный), \n'
                          '-5 (отнять от текущего срока), \n'
                          '+5 (Добавить к текущему сроку)[30]: ')
    answer = 'n' if console.input('Подтвердите обновление[Y]: ').lower() == 'n' else 'y'
    email_settings = load_mail_settings()
    if answer.lower() == 'y':
        for i in keys:
            key = get_key_by_id(int(i))
            disconnect_key(key.config_id.telnet_port, key.name)
            days_ = str(30) if str(days_) == '' else str(days_)
            if days_ and days_[0] == '+':
                days__ = int(get_key_time_for_list(str(key.expired))) + int(days_[1:])
            elif days_ and days_[0] == '-':
                days__ = int(get_key_time_for_list(str(key.expired))) - int(days_[1:])
            else:
                days__ = int(days_)
            info = edit_key_db(name=key.name, days=days__, expired=get_end_date(days__), expired_notification=False)
            if key.email and email_settings['mail_update_key']:
                subject = "Информация об изменении  срока ключа"
                text = f'Срок ключа {key.name} был изменен c {key.days} до {days__} дней<br>'
                text += default_msg(info)
                msg_to_mail(get_settings_db(), key, subject, text)
        input('Ключи успешно обновлены. Нажмите Enter для продолжения...')
        main_menu()
    else:
        input('Обновление ключей отменено. Нажмите Enter для продолжения...')
        main_menu()


def transfer_key():
    keys = select_keys()
    clear()
    table = Table(header_style='bold deep_sky_gray4')
    table.title = 'Список ключей'
    table_start(table)
    for i in keys:
        key = get_key_by_id(int(i))
        if not key.free_key:
            config = str(key.config_id.port) + ':' + key.config_id.protocol
        else:
            config = 'Не привязан'
        table.add_row(str(key.id), key.name, config)
    console.print(table)
    answer = 'n' if console.input('Подтвердите перенос[Y]: ').lower() == 'n' else 'y'
    if answer.lower() == 'y':
        table = Table(header_style='bold magenta')
        table.title = 'Список конфигураций'
        table.add_column('ID', justify='center', style='dim', no_wrap=True)
        table.add_column('Порт', justify='center', style='dim', no_wrap=True)
        table.add_column('Протокол', justify='center', style='dim', no_wrap=True)
        table.add_column('Подсеть', justify='center', style='dim', no_wrap=True)
        table.add_column('Адрес', justify='center', style='dim', no_wrap=True)
        for config in get_configs_db():
            table.add_row(str(config.id), str(config.port), config.protocol, config.subnet, config.address)
        console.print(table)
        config_id = int(console.input('Введите номер конфигурации\n'
                                  '[Введите 99 чтобы сдлеать свободным]: ').strip())
        if config_id == 99:
            for i in keys:
                key = get_key_by_id(i)
                make_free_key(key)
                key.free_key = True
                key.save()
        else:
            for i in keys:
                client.transfer_key(int(i), int(config_id))
            input('Ключи успешно перенесены. Нажмите Enter для продолжения...')
        main_menu()
    else:
        input('Перенос ключей отменен. Нажмите Enter для продолжения...')
        main_menu()


def block_key():
    keys = select_keys()
    clear()
    table = Table(header_style='bold deep_sky_gray4')
    table.title = 'Список ключей'
    table_start(table)
    for i in keys:
        key = get_key_by_id(int(i))
        if not key.free_key:
            config = str(key.config_id.port) + ':' + key.config_id.protocol
        else:
            config = 'Не привязан'
        table.add_row(str(key.id), key.name, config)
    console.print(table)
    answer = 'n' if console.input('Подтвердите блокировку[Y]: ').lower() == 'n' else 'y'
    if answer.lower() == 'y':
        for i in keys:
            client.block_key(get_key_by_id(int(i)))
        input('Ключи успешно заблокирован. Нажмите Enter для продолжения...')
        main_menu()
    else:
        input('Блокировка ключей отменена. Нажмите Enter для продолжения...')
        main_menu()


def unblock_key():
    keys = select_keys()
    clear()
    table = Table(header_style='bold deep_sky_gray4')
    table.title = 'Список ключей'
    table_start(table)
    for i in keys:
        key = get_key_by_id(int(i))
        if not key.free_key:
            config = str(key.config_id.port) + ':' + key.config_id.protocol
        else:
            config = 'Не привязан'
        table.add_row(str(key.id), key.name, config)
    console.print(table)
    answer = 'n' if console.input('Подтвердите разблокировку[Y]: ').lower() == 'n' else 'y'
    if answer.lower() == 'y':
        for i in keys:
            client.unblock_key(get_key_by_id(int(i)))
        input('Ключи успешно разблокирован. Нажмите Enter для продолжения...')
        main_menu()
    else:
        input('Разблокировка ключей отменена. Нажмите Enter для продолжения...')
        main_menu()


def send_key_to_tg():
    keys = select_keys()
    clear()
    table = Table(header_style='bold deep_sky_gray4')
    table.title = 'Список ключей'
    table_start(table)
    for i in keys:
        key = get_key_by_id(int(i))
        if not key.free_key:
            config = str(key.config_id.port) + ':' + key.config_id.protocol
        else:
            config = 'Не привязан'
        table.add_row(str(key.id), key.name, config)
    console.print(table)
    answer = 'n' if console.input('Подтвердите отправку[Y]: ').lower() == 'n' else 'y'
    if answer.lower() == 'y':
        for i in keys:
            key_to_tg(get_key_by_id(int(i)), get_settings_db())
        input('Ключи успешно отправлен в Telegram. Нажмите Enter для продолжения...')
        main_menu()
    else:
        input('Отправка ключей в Telegram отменена. Нажмите Enter для продолжения...')
        main_menu()


def send_key_to_mail():
    keys = select_keys()
    clear()
    table = Table(header_style='bold deep_sky_gray4')
    table.title = 'Список ключей'
    table_start(table)
    for i in keys:
        key = get_key_by_id(int(i))
        if not key.free_key:
            config = str(key.config_id.port) + ':' + key.config_id.protocol
        else:
            config = 'Не привязан'
        table.add_row(str(key.id), key.name, config)
    console.print(table)
    answer = 'n' if console.input('Подтвердите отправку[Y]: ').lower() == 'n' else 'y'
    if answer.lower() == 'y':
        for i in keys:
            key_to_email(get_key_by_id(int(i)), get_settings_db())
        input('Ключи успешно отправлен на почту. Нажмите Enter для продолжения...')
        main_menu()
    else:
        input('Отправка ключей на почту отменена. Нажмите Enter для продолжения...')
        main_menu()


def fix_keys():
    keys = select_keys()
    clear()
    table = Table(header_style='bold deep_sky_gray4')
    table.title = 'Список ключей'
    table_start(table)
    for i in keys:
        key = get_key_by_id(int(i))
        if not key.free_key:
            config = str(key.config_id.port) + ':' + key.config_id.protocol
        else:
            config = 'Не привязан'
        table.add_row(str(key.id), key.name, config)
    console.print(table)
    answer = 'n' if console.input('Подтвердите фикс[Y]: ').lower() == 'n' else 'y'
    if answer.lower() == 'y':
        for i in keys:
            key = get_key_by_id(int(i))
            edit_key_db(name=key.name, connected=False)
            console.print(f'Ключ {key.name} успешно отключен')
        input('Ключи успешно исправлены. Нажмите Enter для продолжения...')
        main_menu()
    else:
        input('Исправление ключей отменено. Нажмите Enter для продолжения...')
        main_menu()


def renew_key():
    keys = select_keys()
    clear()
    table = Table(header_style='bold deep_sky_gray4')
    table.title = 'Список ключей'
    table_start(table)
    for i in keys:
        key = get_key_by_id(int(i))
        if not key.free_key:
            config = str(key.config_id.port) + ':' + key.config_id.protocol
        else:
            config = 'Не привязан'
        table.add_row(str(key.id), key.name, config)
    console.print(table)
    answer = 'n' if console.input('Подтвердите пересоздание[Y]: ').lower() == 'n' else 'y'
    if answer.lower() == 'y':
        for i in keys:
            key = get_key_by_id(int(i))
            client.recreate_key(key.id, get_settings_db().bot_chat_id)
        input('Ключи успешно пересозданы. Нажмите Enter для продолжения...')
        main_menu()
    else:
        input('Пересоздание ключей отменено. Нажмите Enter для продолжения...')
        main_menu()


def add_config():
    clear()
    config = get_config_by_id_db(1)
    table = Table(header_style='bold magenta')
    table.title = 'Список конфигураций'
    table.add_column('ID', justify='center', style='dim', no_wrap=True)
    table.add_column('Порт', justify='center', style='dim', no_wrap=True)
    table.add_column('Протокол', justify='center', style='dim', no_wrap=True)
    table.add_column('Подсеть', justify='center', style='dim', no_wrap=True)
    table.add_column('Адрес', justify='center', style='dim', no_wrap=True)
    for config in get_configs_db():
        table.add_row(str(config.id), str(config.port), config.protocol, config.subnet, config.address)
    console.print(table)
    console.print('\nДобавление конфигурации')
    port = int(console.input('Введите порт: '))
    protocol = console.input('Введите протокол (tcp|udp): ')
    address = console.input(f'Введите адрес[{config.address}]: ')
    telnet_port = random.randint(10000, 65535)
    subnet = console.input('Введите подсеть \n'
                           '(в виде 10.9.0.0/24 для лимита в 254 одновременных подключений или \n'
                           '10.9.0.0/16 для лимита в 65534 одновременных подключений): ')
    console.print('\nСоздание конфигурации...\n')
    try:
        network = ipaddress.ip_network(subnet)
    except ValueError:
        print('Неправильный формат подсети')
        exit(1)

    subnet = str(network.network_address) + '/' + str(network.prefixlen)
    mask = str(network.netmask)
    if not check_config_db(protocol, port, subnet):
        create_config_db(port=port, protocol=protocol, telnet_port=telnet_port, subnet=subnet, address=config.address if address == '' else address)
        subprocess.check_output(f'bash bash/openvpn.sh --add-server "{protocol}" "{port}" "{subnet}" "{mask}" "{telnet_port}"',
                                shell=True)
        input('Конфигурация успешно создана. Нажмите Enter для продолжения...')
        main_menu()
    elif not check_config_db(protocol, port, subnet) and check_config_db('udp', port, '10.8.0.0/16'):
        create_config_db(port=port, protocol=protocol, telnet_port=telnet_port, subnet=subnet, address=config.address if address == '' else address)
        subprocess.check_output(f'bash bash/openvpn.sh --add-server "{protocol}" "{port}" "{subnet}" "{mask}" "{telnet_port}"',
                                shell=True)
        input('Конфигурация успешно активирована. Нажмите Enter для продолжения...')
        main_menu()
    else:
        input('Конфигурация с такими параметрами уже существует. Нажмите Enter для продолжения...')
        main_menu()


def delete_config():
    clear()
    table = Table(header_style='bold magenta')
    table.title = 'Список конфигураций'
    table.add_column('ID', justify='center', style='dim', no_wrap=True)
    table.add_column('Порт', justify='center', style='dim', no_wrap=True)
    table.add_column('Протокол', justify='center', style='dim', no_wrap=True)
    table.add_column('Подсеть', justify='center', style='dim', no_wrap=True)
    table.add_column('Адрес', justify='center', style='dim', no_wrap=True)
    for config in get_configs_db():
        table.add_row(str(config.id), str(config.port), config.protocol, config.subnet, config.address)
    console.print(table)
    config_id = console.input('Введите номер конфигурации: ')
    config = get_config_by_id_db(int(config_id))
    if config_id == '1' or config_id == '':
        input('Нельзя удалить эту конфигурацию. Нажмите Enter для продолжения...')
        main_menu()
    console.print(f'{config.id}. {config.port}:{config.protocol} | {config.subnet}')
    answer = 'n' if console.input('Подтвердите удаление конфигурации[Y]: ').lower() == 'n' else 'y'
    if answer.lower() == 'y':
        keys = view_keys_by_config(config.id, 'all')
        if keys:
            answer = 'n' if console.input(
                'Удалить ключи связанные с конфигурацией? [Y]: ').lower() == 'n' else 'y'
            if answer.lower() == 'y':
                for i in keys:
                    client.delete_key(i)
            else:
                for i in keys:
                    key = get_key_by_id(i)
                    make_free_key(key)
                    key.free_key = True
                    key.save()
        delete_config_db(int(config_id))
        subprocess.check_output(f'bash bash/openvpn.sh --remove-server {config.port} {config.protocol} {config.subnet} {answer}',
                                shell=True)
        input('Конфигурация успешно удалена. Нажмите Enter для продолжения...')
        main_menu()
    else:
        input('Удаление конфигурации отменено. Нажмите Enter для продолжения...')
        main_menu()


def clear_statistics():
    answer = console.input('Очистить статистику? [y/n]: ')
    if answer.lower() == 'y':
        subprocess.check_output('systemctl stop openvpn@server', shell=True)
        subprocess.check_output('systemctl stop openvpn-bot', shell=True)
        subprocess.check_output('systemctl stop openvpn-botapi', shell=True)
        subprocess.check_output('systemctl stop openvpn-api', shell=True)
        for server in get_configs_db():
            if server.id != 0:
                subprocess.check_output(f'systemctl stop openvpn@server-{server.protocol}-{server.port}', shell=True)
        clear_stats_db()
        subprocess.check_output(
            'systemctl restart openvpn-bot; systemctl restart openvpn-botapi; systemctl restart openvpn-api; bash /etc/openvpn/startServer.sh',
            shell=True)
        input('Статистика успешно очищена. Нажмите Enter для продолжения...')
        main_menu()
    else:
        input('Очистка статистики отменена. Нажмите Enter для продолжения...')
        main_menu()


def view_keys():
    clear()
    console.print('────────── Меню просмотра ключей ──────────\n'
                  '1 ➤ Просмотр всех ключей\n'
                  '2 ➤ Просмотр по конфигурации\n'
                  '3 ➤ Просмотр ключей по порту\n'
                  '4 ➤ Просмотр ключей по протоколу\n'
                  '5 ➤ Просмотр ключей по имени\n'
                  '6 ➤ Просмотр ключей по email\n'
                  '7 ➤ Просмотр ключей по статусу\n'
                  '8 ➤ Просмотр подключенных ключей\n'
                  '9 ➤ Просмотр ключей по дате создания\n'
                  '10 ➤ Просмотр ключей по дате окончания\n'
                  '11 ➤ Просмотр ключей по дате обновления\n'
                  '12 ➤ Просмотр ключей по трафику\n'
                  '13 ➤ Просмотр ключей по количеству сессий\n'
                  '14 ➤ Просмотр ключей по общему времени подключения\n'
                  '15 ➤ Просмотр ключей по оставшемуся времени\n'
                  '16 ➤ Просмотр истекших ключей\n'
                  '17 ➤ Просмотр свободных ключей\n'
                  '───────────────────────────────────────────\n'
                  '0 ➤ Вернуться в главное меню\n'
                  '───────────────────────────────────────────')
    key = console.input('Введите номер пункта: ')
    if key == '1':
        info = view_all_keys()
        if info:
            clear()
            for key in info:
                view_key_info(key)
        input('Нажмите Enter для продолжения...')
        view_keys()
    elif key == '2':
        info = view_keys_by_config()
        if info:
            clear()
            for key in info:
                view_key_info(key)
        input('Нажмите Enter для продолжения...')
        view_keys()
    elif key == '3':
        info = view_keys_by_port()
        if info:
            clear()
            for key in info:
                view_key_info(key)
        input('Нажмите Enter для продолжения...')
        view_keys()
    elif key == '4':
        info = view_keys_by_protocol()
        if info:
            clear()
            for key in info:
                view_key_info(key)
        input('Нажмите Enter для продолжения...')
        view_keys()
    elif key == '5':
        info = view_keys_by_name()
        if info:
            clear()
            for key in info:
                view_key_info(key)
        input('Нажмите Enter для продолжения...')
        view_keys()
    elif key == '6':
        info = view_keys_by_email()
        if info:
            clear()
            for key in info:
                view_key_info(key)
        input('Нажмите Enter для продолжения...')
        view_keys()
    elif key == '7':
        info = view_keys_by_status()
        if info:
            clear()
            for key in info:
                view_connection_info(key)
        input('Нажмите Enter для продолжения...')
        view_keys()
    elif key == '8':
        info = view_keys_by_connected()
        if info:
            clear()
            for key in info:
                view_connection_info(key)
        input('Нажмите Enter для продолжения...')
        view_keys()
    elif key == '9':
        info = view_keys_by_created()
        if info:
            clear()
            for key in info:
                view_key_info(key)
        input('Нажмите Enter для продолжения...')
        view_keys()
    elif key == '10':
        info = view_keys_by_expired()
        if info:
            clear()
            for key in info:
                view_key_info(key)
        input('Нажмите Enter для продолжения...')
        view_keys()
    elif key == '11':
        info = view_keys_by_updated()
        if info:
            clear()
            for key in info:
                view_key_info(key)
        input('Нажмите Enter для продолжения...')
        view_keys()
    elif key == '12':
        info = view_keys_by_traffic()
        if info:
            clear()
            for key in info:
                view_connection_info(key)
        input('Нажмите Enter для продолжения...')
        view_keys()
    elif key == '13':
        info = view_keys_by_sessions()
        if info:
            clear()
            for key in info:
                view_connection_info(key)
        input('Нажмите Enter для продолжения...')
        view_keys()
    elif key == '14':
        info = view_keys_by_total_time()
        if info:
            clear()
            for key in info:
                view_connection_info(key)
        input('Нажмите Enter для продолжения...')
        view_keys()
    elif key == '15':
        info = view_keys_by_expired_days()
        if info:
            clear()
            for key in info:
                view_key_info(key)
        input('Нажмите Enter для продолжения...')
        view_keys()
    elif key == '16':
        keys = view_expired_keys()
        if keys:
            for key in keys:
                view_key_info(key)
        input('Нажмите Enter для продолжения...')
        view_keys()
    elif key == '17':
        keys = view_free_keys()
        if keys:
            for key in keys:
                view_key_info(key)
        input('Нажмите Enter для продолжения...')
        view_keys()
    elif key == '0':
        main_menu()
    else:
        view_keys()


def disable_config():
    clear()
    table = Table(header_style='bold magenta')
    table.title = 'Список конфигураций'
    table.add_column('ID', justify='center', style='dim', no_wrap=True)
    table.add_column('Порт', justify='center', style='dim', no_wrap=True)
    table.add_column('Протокол', justify='center', style='dim', no_wrap=True)
    table.add_column('Подсеть', justify='center', style='dim', no_wrap=True)
    table.add_column('Адрес', justify='center', style='dim', no_wrap=True)
    for config in get_configs_db():
        table.add_row(str(config.id), str(config.port), config.protocol, config.subnet, config.address)
    console.print(table)
    config_id = console.input('Введите номер конфигурации: ')
    config = get_config_by_id_db(int(config_id))
    if config:
        disable_config_db(config.id)
        input('Конфигурация успешно отключена. Нажмите Enter для продолжения...')
        main_menu()
    else:
        input('Конфигурация не найдена. Нажмите Enter для продолжения...')
        main_menu()


def enable_config():
    clear()
    table = Table(header_style='bold magenta')
    table.title = 'Список конфигураций'
    table.add_column('ID', justify='center', style='dim', no_wrap=True)
    table.add_column('Порт', justify='center', style='dim', no_wrap=True)
    table.add_column('Протокол', justify='center', style='dim', no_wrap=True)
    table.add_column('Подсеть', justify='center', style='dim', no_wrap=True)
    table.add_column('Адрес', justify='center', style='dim', no_wrap=True)
    for config in get_configs_db():
        table.add_row(str(config.id), str(config.port), config.protocol, config.subnet, config.address)
    console.print(table)
    config_id = console.input('Введите номер конфигурации: ')
    config = get_config_by_id_db(int(config_id))
    if config:
        enable_config_db(config.id)
        input('Конфигурация успешно включена. Нажмите Enter для продолжения...')
        main_menu()
    else:
        input('Конфигурация не найдена. Нажмите Enter для продолжения...')
        main_menu()


def restart_config():
    clear()
    table = Table(header_style='bold magenta')
    table.title = 'Список конфигураций'
    table.add_column('ID', justify='center', style='dim', no_wrap=True)
    table.add_column('Порт', justify='center', style='dim', no_wrap=True)
    table.add_column('Протокол', justify='center', style='dim', no_wrap=True)
    table.add_column('Подсеть', justify='center', style='dim', no_wrap=True)
    table.add_column('Адрес', justify='center', style='dim', no_wrap=True)
    for config in get_configs_db():
        table.add_row(str(config.id), str(config.port), config.protocol, config.subnet, config.address)
    console.print(table)
    config_id = int(console.input('Введите номер конфигурации: '))
    config = get_config_by_id_db(int(config_id))
    if config:
        restart_config_db(config.id)
        input('Конфигурация успешно перезапущена. Нажмите Enter для продолжения...')
        main_menu()
    elif config is None:
        input('Конфигурация не найдена. Нажмите Enter для продолжения...')
        main_menu()


def delete_openvpn():
    clear()
    answer = console.input('Вы уверены, что хотите удалить OpenVPN? (y/n): ')
    if answer == 'y'.lower():
        subprocess.check_output('python3 install.py -u', shell=True)
        input('OpenVPN успешно удален. Нажмите Enter для продолжения...')
        exit()
    else:
        main_menu()


def import_db():
    clear()
    answer = console.input('Вы уверены, что хотите восстановить базу данных? (y/n): ')
    if answer == 'y'.lower():
        link = console.input('Введите ссылку на файл: ')
        subprocess.check_output(f'bash bash/openvpn.sh --restore {link}', shell=True)
        input('База данных успешно восстановлена. Нажмите Enter для продолжения...')
        main_menu()
    else:
        main_menu()


def export_db():
    clear()
    answer = console.input('Вы уверены, что хотите создать резервную копию базы данных? (y/n): ')
    if answer == 'y'.lower():
        out = subprocess.check_output('bash bash/openvpn.sh --backup', shell=True)
        console.print(out)
        input('Резервная копия базы данных успешно создана. Нажмите Enter для продолжения...')
        main_menu()
    else:
        main_menu()


def settings_bot():
    clear()
    settings = get_settings_db()
    bot_token = console.input(f'Введите токен бота (текущий: {settings.bot_token}): ')
    bot_chat_id = console.input(f'Введите UserID (текущий: {settings.bot_chat_id}): ')
    if bot_token != '':
        settings.bot_token = bot_token
        subprocess.check_output(f'systemctl restart openvpn-bot.service', shell=True)
    if bot_chat_id != '':
        settings.bot_chat_id = bot_chat_id
        subprocess.check_output(f'systemctl restart openvpn-bot.service', shell=True)
    settings.save()
    input('Настройки успешно сохранены. Нажмите Enter для продолжения...')
    main_menu()


def settings_mail():
    clear()
    settings = get_settings_db()
    use_mail = console.input(f'Использовать почту? (y/n) (текущий: {settings.use_mail}): ')
    mail_host = console.input(f'Введите хост почты (текущий: {settings.mail_host}): ')
    mail_port = console.input(f'Введите порт почты (текущий: {settings.mail_port}): ')
    mail_login = console.input(f'Введите логин почты (текущий: {settings.mail_login}): ')
    mail_password = console.input(f'Введите пароль почты (текущий: {settings.mail_password}): ')
    if use_mail.lower() == 'y':
        settings.use_mail = True
    elif use_mail.lower() == 'n':
        settings.use_mail = False
    if mail_host != '':
        settings.mail_host = mail_host
    if mail_port != '':
        settings.mail_port = mail_port
    if mail_login != '':
        settings.mail_login = mail_login
    if mail_password != '':
        settings.mail_password = mail_password
    settings.save()
    input('Настройки успешно сохранены. Нажмите Enter для продолжения...')
    main_menu()


def change_address():
    clear()
    table = Table(header_style='bold magenta')
    table.title = 'Список конфигураций'
    table.add_column('ID', justify='center', style='dim', no_wrap=True)
    table.add_column('Порт', justify='center', style='dim', no_wrap=True)
    table.add_column('Протокол', justify='center', style='dim', no_wrap=True)
    table.add_column('Подсеть', justify='center', style='dim', no_wrap=True)
    table.add_column('Адрес', justify='center', style='dim', no_wrap=True)
    for config in get_configs_db():
        table.add_row(str(config.id), str(config.port), config.protocol, config.subnet, config.address)
    console.print(table)
    config_id = console.input('Введите номер конфигурации: ')
    address = console.input('Введите новый адрес конфигурации[Прошлый]: ')
    config = get_config_by_id_db(int(config_id))
    if config:
        edit_config_domain_db(config, config.address if address == '' else address)
        input('Конфигурация успешно отключена. Нажмите Enter для продолжения...')
        main_menu()
    else:
        input('Конфигурация не найдена. Нажмите Enter для продолжения...')
        main_menu()


def send_message_to_mails():
    keys = select_keys()
    clear()
    table = Table(header_style='bold deep_sky_gray4')
    table.title = 'Список ключей'
    table_start(table)
    for i in keys:
        key = get_key_by_id(int(i))
        table.add_row(str(key.id), key.name, f'{key.config_id.port}:{key.config_id.protocol}')
    console.print(table)
    answer = 'n' if console.input('Подтвердите рассылку[Y]: ').lower() == 'n' else 'y'
    if answer.lower() == 'y':
        subject = console.input('Введите тему письма: ')
        text = console.input('Введите текст письма: ')
        settings = get_settings_db()
        sent_email = list()
        all_client_sent = 0
        try:
            smtp = SMTP(settings.mail_host, settings.mail_port)
            smtp.ehlo()
            smtp.starttls()
            smtp.login(settings.mail_login, settings.mail_password)
        except Exception:
            console.print('Ошибка подключения к почте')
            return
        for x, key_id in enumerate(keys):
            current_key = get_key_by_id(int(key_id))
            if current_key.email:
                all_client_sent += 1
                try:
                    msg = MIMEMultipart()
                    msg["From"] = settings.mail_login
                    msg["To"] = current_key.email
                    msg["Subject"] = subject
                    html = u"<!DOCTYPE html><html><head><meta charset=\"UTF-8\"></head><body><p>" + '{} | Имя ключа: {}'.format(
                        text, current_key.name) + u"</p></body></html>"
                    part_html = MIMEText(html, "html")
                    msg.attach(part_html)
                    smtp.sendmail(settings.mail_login, current_key.email, msg.as_string())
                    sent_email.append(current_key.email)
                    console.print(
                        f'{x + 1}. Сообщение отправлено на {current_key.email} | {x + 1}/{len(keys)}')
                except Exception:
                    console.print(
                        f'{x + 1}. Ошибка при отправке сообщения на почту {current_key.email} | {x + 1}/{len(keys)}')
                    time.sleep(0.3)
            else:
                console.print(
                    f'{x + 1}. Не настроена почта для ключа {current_key.name} | {x + 1}/{len(keys)}')
                time.sleep(0.3)
        console.print('Отправка сообщений завершена\n'
                      f'Отправлено {all_client_sent} клиентам и {len(sent_email)} почтам')
    input('Нажмите Enter для продолжения...')
    main_menu()


def change_key_mail():
    keys = select_keys()
    clear()
    table = Table(header_style='bold deep_sky_gray4')
    table.title = 'Список ключей'
    table_start(table)
    for i in keys:
        key = get_key_by_id(int(i))
        table.add_row(str(key.id), key.name, f'{key.config_id.port}:{key.config_id.protocol}')
    console.print(table)
    answer = 'n' if console.input('Подтвердите изменения[Y]: ').lower() == 'n' else 'y'
    if answer.lower() == 'y':
        email = console.input('Введите новую почту: ')
        for i in keys:
            key = get_key_by_id(int(i))
            edit_key_db(name=key.name, email=email)
            console.print(f'Ключ {key.name} успешно изменен')
        input('Ключи успешно изменены. Нажмите Enter для продолжения...')
        main_menu()
    else:
        input('Изменение ключей отменено. Нажмите Enter для продолжения...')
        main_menu()


def edit_config():
    clear()
    table = Table(header_style='bold magenta')
    table.title = 'Список конфигураций'
    table.add_column('ID', justify='center', style='dim', no_wrap=True)
    table.add_column('Порт', justify='center', style='dim', no_wrap=True)
    table.add_column('Протокол', justify='center', style='dim', no_wrap=True)
    table.add_column('Подсеть', justify='center', style='dim', no_wrap=True)
    for config in get_configs_db():
        table.add_row(str(config.id), str(config.port), config.protocol, config.subnet)
    console.print(table)
    config_id = int(console.input('Введите номер конфигурации: '))
    config = get_config_by_id_db(int(config_id))
    if config:
        if config.id == 1:
            input('Нельзя изменить конфигурацию по умолчанию. Нажмите Enter для продолжения...')
            main_menu()
        subprocess.run(['nano', f'/etc/openvpn/server-{config.protocol}-{config.port}.conf'])
        restart_config_db(config.id)
        input('Конфигурация успешно изменена и перезапущена. Нажмите Enter для продолжения...')
        main_menu()
    elif config is None:
        input('Конфигурация не найдена. Нажмите Enter для продолжения...')
        main_menu()


def edit_config_key():
    clear()
    subprocess.run(['nano', '/etc/openvpn/client-template.txt'])
    input('Конфигурация успешно изменена. Нажмите Enter для продолжения...')
    main_menu()


def clear_keys_traffic():
    keys = select_keys()
    clear()
    table = Table(header_style='bold deep_sky_gray4')
    table.title = 'Список ключей'
    table_start(table)
    for i in keys:
        key = get_key_by_id(int(i))
        if not key.free_key:
            config = str(key.config_id.port) + ':' + key.config_id.protocol
        else:
            config = 'Не привязан'
        table.add_row(str(key.id), key.name, config)
    console.print(table)
    answer = 'n' if console.input('Подтвердите очистку[Y]: ').lower() == 'n' else 'y'
    if answer.lower() == 'y':
        for i in keys:
            key = get_key_by_id(int(i))
            delete_session_db(key.id)
        input('Ключи успешно очищены. Нажмите Enter для продолжения...')
        main_menu()
    else:
        input('Очистка ключей отменена. Нажмите Enter для продолжения...')
        main_menu()


def edit_mail_settings():
    clear()
    settings = load_mail_settings()
    console.print('Настройки оповещения по почте')
    console.print(f'1. {"Включить" if not settings["mail_create_key"] else "Выключить"} оповещение о создании ключа')
    console.print(f'2. {"Включить" if not settings["mail_delete_key"] else "Выключить"} оповещение об удалении ключа')
    console.print(
        f'3. {"Включить" if not settings["mail_expired_key"] else "Выключить"} оповещение об истечении срока действия ключа')
    console.print(f'4. {"Включить" if not settings["mail_block_key"] else "Выключить"} оповещение о блокировке ключа')
    console.print(
        f'5. {"Включить" if not settings["mail_unblock_key"] else "Выключить"} оповещение о разблокировке ключа')
    console.print(
        f'6. {"Включить" if not settings["mail_day_before_expired"] else "Выключить"} оповещение за 1 день до истечения срока действия ключа')
    console.print(
        f'7. {"Включить" if not settings["mail_week_before_expired"] else "Выключить"} оповещение за 7 деня до истечения срока действия ключа')
    console.print(f'8. {"Включить" if not settings["mail_update_key"] else "Выключить"} оповещение об обновлении ключа')
    console.print(f'9. {"Включить" if not settings["mail_renew_key"] else "Выключить"} оповещение о пересоздании ключа')
    console.print(f'10. {"Включить" if not settings["mail_transfer_key"] else "Выключить"} оповещение о переносе ключа')
    console.print(f'11. {"Включить" if not settings["mail_traffic_limit"] else "Выключить"} оповещение о превышении трафика')
    console.print('0. Назад')
    answer = int(input('Выберите пункт меню: '))
    if answer == 1:
        settings['mail_create_key'] = False if settings['mail_create_key'] else True
        save_mail_settings(settings)
        edit_mail_settings()
    elif answer == 2:
        settings['mail_delete_key'] = False if settings['mail_delete_key'] else True
        save_mail_settings(settings)
        edit_mail_settings()
    elif answer == 3:
        settings['mail_expired_key'] = False if settings['mail_expired_key'] else True
        save_mail_settings(settings)
        edit_mail_settings()
    elif answer == 4:
        settings['mail_block_key'] = False if settings['mail_block_key'] else True
        save_mail_settings(settings)
        edit_mail_settings()
    elif answer == 5:
        settings['mail_unblock_key'] = False if settings['mail_unblock_key'] else True
        save_mail_settings(settings)
        edit_mail_settings()
    elif answer == 6:
        settings['mail_day_before_expired'] = False if settings['mail_day_before_expired'] else True
        save_mail_settings(settings)
        edit_mail_settings()
    elif answer == 7:
        settings['mail_week_before_expired'] = False if settings['mail_week_before_expired'] else True
        save_mail_settings(settings)
        edit_mail_settings()
    elif answer == 8:
        settings['mail_update_key'] = False if settings['mail_update_key'] else True
        save_mail_settings(settings)
        edit_mail_settings()
    elif answer == 9:
        settings['mail_renew_key'] = False if settings['mail_renew_key'] else True
        save_mail_settings(settings)
        edit_mail_settings()
    elif answer == 10:
        settings['mail_transfer_key'] = False if settings['mail_transfer_key'] else True
        save_mail_settings(settings)
        edit_mail_settings()
    elif answer == 11:
        settings['mail_traffic_limit'] = False if settings['mail_traffic_limit'] else True
        save_mail_settings(settings)
        edit_mail_settings()
    else:
        extra_menu()

def extra_menu():
    clear()
    console.print(f'─────────── Конфигурации ───────────\n'
                  f'1 ➤ Добавить конфигурацию\n'
                  f'2 ➤ Удалить конфигурацию\n'
                  f'3 ➤ Отключить конфигурацию\n'
                  f'4 ➤ Включить конфигурацию\n'
                  f'5 ➤ Перезапустить конфигурацию\n'
                  f'6 ➤ Редактировать конфигурацию\n'
                  f'7 ➤ Редактировать конфигурацию ключа\n'
                  f'8 ➤ Изменить адрес конфигурации\n'
                  f'────────── Дополнительно ───────────\n'
                  f'9 ➤ Удалить OpenVPN\n'
                  f'10 ➤ Выгрузить базу\n'
                  f'11 ➤ Загрузить базу\n'
                  f'12 ➤ Настройки бота\n'
                  f'13 ➤ Настройки почты\n'
                  f'14 ➤ Статистика сервера\n'
                  f'15 ➤ Рассылка сообщения по почтам\n'
                  f'16 ➤ Очистка статистики\n'
                  f'17 ➤ Обновить скрипт\n'
                  f'18 ➤ Настрока оповещений\n'
                  f'────────────── Назад ───────────────\n'
                  f'0 ➤ Назад в главное меню\n'
                  f'────────────────────────────────────')
    try:
        key = console.input('Введите номер пункта: ')
        if key == '1':
            add_config()
        elif key == '2':
            delete_config()
        elif key == '3':
            disable_config()
        elif key == '4':
            enable_config()
        elif key == '5':
            restart_config()
        elif key == '6':
            edit_config()
        elif key == '7':
            edit_config_key()
        elif  key == '8':
            change_address()
        elif key == '9':
            delete_openvpn()
        elif key == '10':
            export_db()
        elif key == '11':
            import_db()
        elif key == '12':
            settings_bot()
        elif key == '13':
            settings_mail()
        elif key == '14':
            main_menu_statistics()
            input('Нажмите Enter для продолжения...')
            main_menu()
        elif key == '15':
            send_message_to_mails()
        elif key == '16':
            clear_statistics()
        elif key == '17':
            settings = get_settings_db()
            if not update_script(settings.bot_chat_id):
                input('Нажмите Enter для продолжения...')
                main_menu()
        elif key == '18':
            edit_mail_settings()
        elif key == '0':
            main_menu()
        else:
            extra_menu()
    except KeyboardInterrupt:
        clear()
        exit()


def print_banner():
    # Ваш ascii-баннер с синим цветом
    console.print(
        "[bold blue]\n"
        "   ____                           __  ___             __\n"
        "  / __ \\  ____   ___    ____     /  |/  / ____   ____/ /\n"
        " / / / / / __ \\ / _ \\  / __ \\   / /|_/ / / __ \\ / __  / \n"
        "/ /_/ / / /_/ //  __/ / / / /  / /  / / / /_/ // /_/ /  \n"
        "\\____/ / .___/ \\___/ /_/ /_/  /_/  /_/  \\____/ \\__,_/   \n"
        "      /_/                                               \n"
        "               OpenVPN:MOD | by:@SDEV_51              \n"
        "[/bold blue]",
    )
    console.print("[green]@SDEV_51[/green]\n")

def main_menu():
    clear()
    print_banner()
    console.print(f"[green]────────────── Создание ───────────────[/green]")
    console.print(f"[green]1[/green] [gray]Создать ключ[/gray]")
    console.print(f"[green]2[/green] [gray]Удалить ключ[/gray]")
    console.print(f"[green]─────────── Редактирование ────────────[/green]")
    console.print(f"[green]3[/green] [gray]Перевести ключ[/gray]")
    console.print(f"[green]4[/green] [gray]Пересоздать ключ[/gray]")
    console.print(f"[green]5[/green] [gray]Изменить срок ключа[/gray]")
    console.print(f"[green]6[/green] [gray]Изменить почту ключа[/gray]")
    console.print(f"[green]7[/green] [gray]Фикс ключей[/gray]")
    console.print(f"[green]────────────── Просмотр ───────────────[/green]")
    console.print(f"[green]8[/green] [gray]Список ключей[/gray]")
    console.print(f"[green]9[/green] [gray]Просмотр сессий ключа[/gray]")
    console.print(f"[green]────────────── Контроль ───────────────[/green]")
    console.print(f"[green]10[/green] [gray]Заблокировать ключ[/gray]")
    console.print(f"[green]11[/green] [gray]Разблокировать ключ[/gray]")
    console.print(f"[green]12[/green] [gray]Очистить трафик ключей[/gray]")
    console.print(f"[green]────────────── Отправка ───────────────[/green]")
    console.print(f"[green]13[/green] [gray]Отправить ключ в Telegram[/gray]")
    console.print(f"[green]14[/green] [gray]Отправить ключ на почту[/gray]")
    console.print(f"[green]─────────── Дополнительно ─────────────[/green]")
    console.print(f"[green]15[/green] [gray]Дополнительное меню[/gray]")
    console.print(f"[green]──────────────── Выход ────────────────[/green]")
    console.print(f"[green]0[/green] [gray]Выход[/gray]")
    console.print(f"[green]────────────────────────────────────[/green]")
    try:
        key = console.input('[gray]Введите номер пункта:[/gray] ')
        if key == '1':
            create_key()
        elif key == '2':
            delete_key()
        elif key == '3':
            transfer_key()
        elif key == '4':
            renew_key()
        elif key == '5':
            edit_days_key()
        elif key == '6':
            change_key_mail()
        elif key == '7':
            fix_keys()
        elif key == '8':
            view_keys()
        elif key == '9':
            keys = select_keys()
            if keys:
                for key in keys:
                    view_key_sessions(key)
                    input('Нажмите Enter для продолжения...')
            else:
                input('Нажмите Enter для продолжения...')
            main_menu()
        elif key == '10':
            block_key()
        elif key == '11':
            unblock_key()
        elif key == '12':
            clear_keys_traffic()
        elif key == '13':
            send_key_to_tg()
        elif key == '14':
            send_key_to_mail()
        elif key == '15':
            extra_menu()
        elif key == '0':
            exit()
        elif key == '999':
            settings = get_settings_db()
            if not update_script(settings.bot_chat_id):
                input('Нажмите Enter для продолжения...')
                main_menu()
        else:
            main_menu()
    except KeyboardInterrupt:
        clear()
        exit()


if __name__ == '__main__':
    main_menu()
