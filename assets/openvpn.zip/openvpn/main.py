# coding=utf-8
import ipaddress
import random
from rich.console import Console
from rich.table import Table
from rich.text import Text

import functions.client as client
from functions.data.settings import *
from functions.list import *
from functions.other import *
from functions.server_control import *

console = Console()

def table_start(table):
    table.add_column('ID', justify='center')
    table.add_column('Имя', justify='center')
    table.add_column('Порт:Протокол', justify='center')

def create_key():
    clear()
    settings = get_settings_db()
    table = Table(header_style='bold magenta')
    table.title = 'Список конфигураций'
    table.add_column('ID', justify='center', style='dim', no_wrap=True)
    table.add_column('Порт', justify='center', style='dim', no_wrap=True)
    table.add_column('Протокол', justify='center', style='dim', no_wrap=True)
    table.add_column('Подсеть', justify='center', style='dim', no_wrap=True)
    table.add_column('Адрес', justify='center', style='dim', no_wrap=True)
    for config in get_configs_db():
        table.add_row(str(config.id), str(config.port), config.protocol, config.subnet, config.address)
    console.print(table)
    config_id = console.input('\nВведите номер конфигурации: ')
    name = console.input('Введите имя ключа[Рандомное]: ')
    days = console.input('Введите количество дней действия ключа[30]: ')
    amount = console.input('Введите количество ключей[1]: ')
    console.print('\nСоздание ключей...\n')
    client.create_key(
        name=random_name() if name == '' else name,
        days=30 if days == '' else int(days),
        amount=1 if amount == '' else int(amount),
        config_id=int(config_id)
    )
    input('Нажмите Enter для продолжения...')
    main_menu()

def delete_key():
    clear()
    keys = select_keys()
    clear()
    table = Table(header_style='bold deep_sky_blue4')
    table.add_column('ID', justify='center')
    table.add_column('Имя', justify='center')
    table.add_column('Осталось дней', justify='center')
    table.add_column('Порт:Протокол', justify='center')
    for i in keys:
        key = get_key_by_id(int(i))
        if not key.free_key:
            config = str(key.config_id.port) + ':' + key.config_id.protocol
        else:
            config = 'Не привязан'
        table.add_row(str(key.id), key.name, str(get_key_time_for_list(str(key.expired))), config)
    console.print(table)
    answer = 'n' if console.input('Подтвердите удаление[Y]: ').lower() == 'n' else 'y'
    if answer.lower() == 'y':
        clear()
        for i in keys:
            client.delete_key(int(i))
        input('Ключи успешно удалены. Нажмите Enter для продолжения...')
        main_menu()
    else:
        input('Удаление ключей отменено. Нажмите Enter для продолжения...')
        main_menu()

def edit_days_key():
    keys = select_keys()
    clear()
    table = Table(header_style='bold deep_sky_blue4')
    table.title = 'Список ключей'
    table_start(table)
    table.add_column('Осталось дней', justify='center')
    for i in keys:
        key = get_key_by_id(int(i))
        if not key.free_key:
            config = str(key.config_id.port) + ':' + key.config_id.protocol
        else:
            config = 'Не привязан'
        table.add_row(str(key.id), key.name, config, str(get_key_time_for_list(str(key.expired))))
    console.print(table)
    days_ = console.input('Введите срок ключа\n'
                          '30 (фиксированный), \n'
                          '-5 (отнять от текущего срока), \n'
                          '+5 (Добавить к текущему сроку)[30]: ')
    answer = 'n' if console.input('Подтвердите обновление[Y]: ').lower() == 'n' else 'y'
    if answer.lower() == 'y':
        for i in keys:
            key = get_key_by_id(int(i))
            disconnect_key(key.config_id.telnet_port, key.name)
            days_ = str(30) if str(days_) == '' else str(days_)
            if days_ and days_[0] == '+':
                days__ = int(get_key_time_for_list(str(key.expired))) + int(days_[1:])
            elif days_ and days_[0] == '-':
                days__ = int(get_key_time_for_list(str(key.expired))) - int(days_[1:])
            else:
                days__ = int(days_)
            info = edit_key_db(name=key.name, days=days__, expired=get_end_date(days__), expired_notification=False)
        input('Ключи успешно обновлены. Нажмите Enter для продолжения...')
        main_menu()
    else:
        input('Обновление ключей отменено. Нажмите Enter для продолжения...')
        main_menu()

def fix_keys():
    keys = select_keys()
    clear()
    table = Table(header_style='bold deep_sky_blue4')
    table.title = 'Список ключей'
    table_start(table)
    for i in keys:
        key = get_key_by_id(int(i))
        if not key.free_key:
            config = str(key.config_id.port) + ':' + key.config_id.protocol
        else:
            config = 'Не привязан'
        table.add_row(str(key.id), key.name, config)
    console.print(table)
    answer = 'n' if console.input('Подтвердите фикс[Y]: ').lower() == 'n' else 'y'
    if answer.lower() == 'y':
        for i in keys:
            key = get_key_by_id(int(i))
            edit_key_db(name=key.name, connected=False)
            console.print(f'Ключ {key.name} успешно отключен')
        input('Ключи успешно исправлены. Нажмите Enter для продолжения...')
        main_menu()
    else:
        input('Исправление ключей отменено. Нажмите Enter для продолжения...')
        main_menu()

def block_key():
    keys = select_keys()
    clear()
    table = Table(header_style='bold deep_sky_blue4')
    table.title = 'Список ключей'
    table_start(table)
    for i in keys:
        key = get_key_by_id(int(i))
        if not key.free_key:
            config = str(key.config_id.port) + ':' + key.config_id.protocol
        else:
            config = 'Не привязан'
        table.add_row(str(key.id), key.name, config)
    console.print(table)
    answer = 'n' if console.input('Подтвердите блокировку[Y]: ').lower() == 'n' else 'y'
    if answer.lower() == 'y':
        for i in keys:
            client.block_key(get_key_by_id(int(i)))
        input('Ключи успешно заблокирован. Нажмите Enter для продолжения...')
        main_menu()
    else:
        input('Блокировка ключей отменена. Нажмите Enter для продолжения...')
        main_menu()

def unblock_key():
    keys = select_keys()
    clear()
    table = Table(header_style='bold deep_sky_blue4')
    table.title = 'Список ключей'
    table_start(table)
    for i in keys:
        key = get_key_by_id(int(i))
        if not key.free_key:
            config = str(key.config_id.port) + ':' + key.config_id.protocol
        else:
            config = 'Не привязан'
        table.add_row(str(key.id), key.name, config)
    console.print(table)
    answer = 'n' if console.input('Подтвердите разблокировку[Y]: ').lower() == 'n' else 'y'
    if answer.lower() == 'y':
        for i in keys:
            client.unblock_key(get_key_by_id(int(i)))
        input('Ключи успешно разблокирован. Нажмите Enter для продолжения...')
        main_menu()
    else:
        input('Разблокировка ключей отменена. Нажмите Enter для продолжения...')
        main_menu()

def clear_keys_traffic():
    keys = select_keys()
    clear()
    table = Table(header_style='bold deep_sky_blue4')
    table.title = 'Список ключей'
    table_start(table)
    for i in keys:
        key = get_key_by_id(int(i))
        if not key.free_key:
            config = str(key.config_id.port) + ':' + key.config_id.protocol
        else:
            config = 'Не привязан'
        table.add_row(str(key.id), key.name, config)
    console.print(table)
    answer = 'n' if console.input('Подтвердите очистку[Y]: ').lower() == 'n' else 'y'
    if answer.lower() == 'y':
        for i in keys:
            key = get_key_by_id(int(i))
            delete_session_db(key.id)
        input('Ключи успешно очищены. Нажмите Enter для продолжения...')
        main_menu()
    else:
        input('Очистка ключей отменена. Нажмите Enter для продолжения...')
        main_menu()

def renew_key():
    keys = select_keys()
    clear()
    table = Table(header_style='bold deep_sky_blue4')
    table.title = 'Список ключей'
    table_start(table)
    for i in keys:
        key = get_key_by_id(int(i))
        if not key.free_key:
            config = str(key.config_id.port) + ':' + key.config_id.protocol
        else:
            config = 'Не привязан'
        table.add_row(str(key.id), key.name, config)
    console.print(table)
    answer = 'n' if console.input('Подтвердите пересоздание[Y]: ').lower() == 'n' else 'y'
    if answer.lower() == 'y':
        for i in keys:
            key = get_key_by_id(int(i))
            client.recreate_key(key.id, get_settings_db().bot_chat_id)
        input('Ключи успешно пересозданы. Нажмите Enter для продолжения...')
        main_menu()
    else:
        input('Пересоздание ключей отменено. Нажмите Enter для продолжения...')
        main_menu()

def send_key_to_tg():
    keys = select_keys()
    clear()
    table = Table(header_style='bold deep_sky_blue4')
    table.title = 'Список ключей'
    table_start(table)
    for i in keys:
        key = get_key_by_id(int(i))
        if not key.free_key:
            config = str(key.config_id.port) + ':' + key.config_id.protocol
        else:
            config = 'Не привязан'
        table.add_row(str(key.id), key.name, config)
    console.print(table)
    answer = 'n' if console.input('Подтвердите отправку[Y]: ').lower() == 'n' else 'y'
    if answer.lower() == 'y':
        for i in keys:
            key_to_tg(get_key_by_id(int(i)), get_settings_db())
        input('Ключи успешно отправлен в Telegram. Нажмите Enter для продолжения...')
        main_menu()
    else:
        input('Отправка ключей в Telegram отменена. Нажмите Enter для продолжения...')
        main_menu()

def select_keys() -> list:
    clear()
    console.print('Меню просмотра ключей\n'
                  + Text("1", style="bold green") + ". Просмотр всех ключей\n"
                  + Text("2", style="bold green") + ". Просмотр по конфигурации\n"
                  + Text("3", style="bold green") + ". Просмотр ключей по порту\n"
                  + Text("4", style="bold green") + ". Просмотр ключей по протоколу\n"
                  + Text("5", style="bold green") + ". Просмотр ключей по имени\n"
                  + Text("6", style="bold green") + ". Просмотр ключей по статусу\n"
                  + Text("7", style="bold green") + ". Просмотр подключенных ключей\n"
                  + Text("8", style="bold green") + ". Просмотр ключей по дате создания\n"
                  + Text("9", style="bold green") + ". Просмотр ключей по дате окончания\n"
                  + Text("10", style="bold green") + ". Просмотр ключей по дате обновления\n"
                  + Text("11", style="bold green") + ". Просмотр ключей по трафику\n"
                  + Text("12", style="bold green") + ". Просмотр ключей по количеству сессий\n"
                  + Text("13", style="bold green") + ". Просмотр ключей по общему времени подключения\n"
                  + Text("14", style="bold green") + ". Просмотр ключей по оставшемуся времени\n"
                  + Text("15", style="bold green") + ". Просмотр истекших ключей\n"
                  + Text("16", style="bold green") + ". Просмотр свободных ключей\n"
                  + Text("0", style="bold green") + ". Вернуться в главное меню\n")
    choice = console.input('Введите номер: ')
    if choice == '1':
        keys = view_all_keys()
    elif choice == '2':
        keys = view_keys_by_config()
    elif choice == '3':
        keys = view_keys_by_port()
    elif choice == '4':
        keys = view_keys_by_protocol()
    elif choice == '5':
        keys = view_keys_by_name()
    elif choice == '6':
        keys = view_keys_by_status()
    elif choice == '7':
        keys = view_keys_by_connected()
    elif choice == '8':
        keys = view_keys_by_created()
    elif choice == '9':
        keys = view_keys_by_expired()
    elif choice == '10':
        keys = view_keys_by_updated()
    elif choice == '11':
        keys = view_keys_by_traffic()
    elif choice == '12':
        keys = view_keys_by_sessions()
    elif choice == '13':
        keys = view_keys_by_total_time()
    elif choice == '14':
        keys = view_keys_by_expired_days()
    elif choice == '15':
        keys = view_expired_keys()
    elif choice == '16':
        keys = view_free_keys()
    elif choice == '0':
        keys = []
        main_menu()
    else:
        keys = []
        select_keys()
    return keys

def extra_menu():
    clear()
    console.print(
        Text("1", style="bold green") + ". Добавить конфигурацию\n" +
        Text("2", style="bold green") + ". Удалить конфигурацию\n" +
        Text("3", style="bold green") + ". Отключить конфигурацию\n" +
        Text("4", style="bold green") + ". Включить конфигурацию\n" +
        Text("5", style="bold green") + ". Перезапустить конфигурацию\n" +
        Text("6", style="bold green") + ". Редактировать конфигурацию\n" +
        Text("7", style="bold green") + ". Редактировать конфигурацию ключа\n" +
        Text("8", style="bold green") + ". Изменить адрес конфигурации\n" +
        Text("9", style="bold green") + ". Удалить OpenVPN\n" +
        Text("10", style="bold green") + ". Выгрузить базу\n" +
        Text("11", style="bold green") + ". Загрузить базу\n" +
        Text("12", style="bold green") + ". Настройки бота\n" +
        Text("13", style="bold green") + ". Статистика сервера\n" +
        Text("14", style="bold green") + ". Очистка статистики\n" +
        Text("15", style="bold green") + ". Обновить скрипт\n" +
        Text("0", style="bold green") + ". Назад в главное меню\n"
    )
    try:
        key = console.input('Введите номер пункта: ')
        if key == '1':
            add_config()
        elif key == '2':
            delete_config()
        elif key == '3':
            disable_config()
        elif key == '4':
            enable_config()
        elif key == '5':
            restart_config()
        elif key == '6':
            edit_config()
        elif key == '7':
            edit_config_key()
        elif key == '8':
            change_address()
        elif key == '9':
            delete_openvpn()
        elif key == '10':
            export_db()
        elif key == '11':
            import_db()
        elif key == '12':
            settings_bot()
        elif key == '13':
            main_menu_statistics()
            input('Нажмите Enter для продолжения...')
            main_menu()
        elif key == '14':
            clear_statistics()
        elif key == '15':
            settings = get_settings_db()
            if not update_script(settings.bot_chat_id):
                input('Нажмите Enter для продолжения...')
                main_menu()
        elif key == '0':
            main_menu()
        else:
            extra_menu()
    except KeyboardInterrupt:
        clear()
        exit()

def main_menu():
    clear()
    # Синий баннер наверху
    banner = """

░█████╗░██████╗░███████╗███╗░░██╗███╗░░░███╗░█████╗░██████╗░
██╔══██╗██╔══██╗██╔════╝████╗░██║████╗░████║██╔══██╗██╔══██╗
██║░░██║██████╔╝█████╗░░██╔██╗██║██╔████╔██║██║░░██║██║░░██║
██║░░██║██╔═══╝░██╔══╝░░██║╚████║██║╚██╔╝██║██║░░██║██║░░██║
╚█████╔╝██║░░░░░███████╗██║░╚███║██║░╚═╝░██║╚█████╔╝██████╔╝
░╚════╝░╚═╝░░░░░╚══════╝╚═╝░░╚══╝╚═╝░░░░░╚═╝░╚════╝░╚═════╝░
               OpenVPN:MOD | автор @XSFORM
    """
    console.print(Text(banner, style="bold blue"))
    menu_items = [
        "Создать ключ",
        "Удалить ключ",
        "Пересоздать ключ",
        "Изменить срок ключа",
        "Фикс ключей",
        "Список ключей",
        "Заблокировать ключ",
        "Разблокировать ключ",
        "Очистить трафик ключей",
        "Отправить ключ в Telegram",
        "Дополнительное меню",
        "Выход"
    ]
    for idx, item in enumerate(menu_items, start=1):
        if item == "Выход":
            console.print(Text("0", style="bold green") + Text(". " + item, style="bold white"))
        else:
            console.print(Text(str(idx), style="bold green") + Text(". " + item, style="bold white"))
    try:
        key = console.input('Введите номер пункта: ')
        if key == '1':
            create_key()
        elif key == '2':
            delete_key()
        elif key == '3':
            renew_key()
        elif key == '4':
            edit_days_key()
        elif key == '5':
            fix_keys()
        elif key == '6':
            select_keys()
        elif key == '7':
            block_key()
        elif key == '8':
            unblock_key()
        elif key == '9':
            clear_keys_traffic()
        elif key == '10':
            send_key_to_tg()
        elif key == '11':
            extra_menu()
        elif key == '0':
            exit()
        elif key == '999':
            settings = get_settings_db()
            if not update_script(settings.bot_chat_id):
                input('Нажмите Enter для продолжения...')
                main_menu()
        else:
            main_menu()
    except KeyboardInterrupt:
        clear()
        exit()

if __name__ == '__main__':
    main_menu()